//
//  libnode.h
//  libnode
//
//  Created by Jaime Bernardo on 11/05/2017.
//  Copyright © 2017 Janea Systems. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for libnode.
FOUNDATION_EXPORT double libnodeVersionNumber;

//! Project version string for libnode.
FOUNDATION_EXPORT const unsigned char libnodeVersionString[];

#import "node.hpp"
