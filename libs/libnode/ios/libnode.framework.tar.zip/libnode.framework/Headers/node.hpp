//
//  node.hpp
//  libnode
//
//  Created by Jaime Bernardo on 10/05/2017.
//  Copyright © 2017 Janea Systems. All rights reserved.
//

#ifndef node_hpp
#define node_hpp

namespace node {
    int Start(int argc, char *argv[]);
} // namespace node

#endif /* node_hpp */


